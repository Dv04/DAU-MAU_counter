# DP-accurate DAU/MAU Counter Under Deletions

Implement a differential-privacy aware turnstile streaming pipeline that reports distinct Daily Active Users (DAU) and rolling 30-day Monthly Active Users (MAU), while honoring user deletion requests. The proof-of-concept targets correctness, clarity, and reproducibility within four weeks. The default sketch is a KMV bottom-k approximation with optional Bloom-filter aided deletions; an exact set implementation remains for tests, and Theta is available when DataSketches is installed. Laplace/Gaussian mechanisms inject calibrated noise derived from a flippancy bound {{W_BOUND}}.

## Quickstart in 120 seconds
1. `cd dp-dau-mau && python -m venv .venv && source .venv/bin/activate`
2. `pip install -r requirements.txt`
3. Export runtime placeholders (update the values to suit your environment):

   ```bash
   export DATA_DIR="$PWD/.local-data" \
          SERVICE_HOST="http://127.0.0.1:8000" \
          SERVICE_API_KEY="changeme-super-secret" \
          EPSILON_DAU=0.3 EPSILON_MAU=0.5 DELTA=1e-6 \
          ADVANCED_DELTA=1e-7 RDP_ORDERS="1.25,1.5,2,4,8,16" \
          MAU_WINDOW_DAYS=30 COVERAGE_THRESHOLD=70
   ```

4. Start the API: `make run` (FastAPI + Uvicorn reload).
5. Generate a sample stream under `{{DATA_DIR}}/streams/`: 

   ```bash
   python -m cli.dpdau generate-synthetic \
     --days {{DAYS}} --users {{N_USERS}} \
     --p-active {{P_ACTIVE}} --delete-rate {{DELETE_RATE}} \
     --out {{DATA_DIR}}/streams/example.jsonl
   ```

6. Ingest and query through the service:

   ```bash
   python -m cli.dpdau ingest \
     --from {{DATA_DIR}}/streams/example.jsonl \
     --format jsonl --host "$SERVICE_HOST" --api-key "$SERVICE_API_KEY"

   python -m cli.dpdau dau --day 2025-10-01 --host "$SERVICE_HOST" --api-key "$SERVICE_API_KEY"
   python -m cli.dpdau mau --end 2025-10-31 --window {{MAU_WINDOW_DAYS}} --host "$SERVICE_HOST" --api-key "$SERVICE_API_KEY"
   ```

7. Call the HTTP endpoints (remember the API key header):

   ```bash
   curl "$SERVICE_HOST/dau/2025-10-31" -H "X-API-Key: $SERVICE_API_KEY"
   curl "$SERVICE_HOST/mau?end=2025-10-31&window={{MAU_WINDOW_DAYS}}" -H "X-API-Key: $SERVICE_API_KEY"
   curl "$SERVICE_HOST/budget/mau?day=2025-10-31" -H "X-API-Key: $SERVICE_API_KEY"
   ```

8. Run the smoke flow any time you change code: `./scripts/smoke.sh`

## Core Concepts
- **Turnstile stream**: each record toggles membership with `op` ∈ {`+`, `-`}. Deletes trigger retroactive rebuilds via the erasure ledger.
- **Differential privacy**: per-user sensitivity bounded by {{W_BOUND}}; Laplace noise parameterized by {{EPSILON_DAU}} / {{EPSILON_MAU}} with optional Gaussian via {{DELTA}}.
- **Flippancy**: cap on how often a user can toggle within the reporting horizon.
- **Privacy accounting**: SQLite ledger tracks naive ε spending and Rényi orders {{RDP_ORDERS}}, exposing remaining budget via API/CLI.
- **Sketch abstraction**: choose `{{SKETCH_IMPL}}` = `kmv`, `set`, or `theta`; rebuild strategy documented in `HANDOFF.md`.

```mermaid
sequenceDiagram
    participant Client
    participant API as FastAPI Service
    participant Pipeline
    participant Ledger
    participant Accountant
    Client->>API: POST /event {user_id, op, day}
    API->>Pipeline: ingest_event(...)
    Pipeline->>Ledger: record_activity / record_erasure
    Pipeline->>Accountant: can_release(metric, ε)
    Accountant-->>Pipeline: remaining budget
    Pipeline-->>API: ack + status
    Client->>API: GET /dau/{day}
    API->>Pipeline: get_daily_release(day)
    Pipeline->>Accountant: record_release
    Pipeline-->>API: {estimate, CI, ε, δ, sketch}
```

## Privacy & Budget
- **Per-release noise:** DAU uses Laplace with ε = {{EPSILON_DAU}} and δ = 0; MAU uses Gaussian with ε = {{EPSILON_MAU}} and δ = {{DELTA}}. The flippancy bound {{W_BOUND}} caps user contribution.
- **RDP ledger:** every release logs ε(α) for each order in {{RDP_ORDERS}} into `rdp_releases`. The accountant converts curves using ε = ε(α) + ln(1/δ)/(α-1) and selects the tightest α for the configured δ.
- **Monthly caps:** set {{DAU_BUDGET_TOTAL}} and {{MAU_BUDGET_TOTAL}} to enforce per-metric ε limits. When RDP orders are absent the accountant falls back to naive summation and reports `policy.composition = "naive"`.
- **Budget API:** `GET /budget/{metric}?day=YYYY-MM-DD` returns the composed ε spent in that month, remaining margin, best RDP epsilon/order (when available), and a structured policy with `monthly_cap`, `composition`, and explanatory `notes`.
- **Exhaustion behaviour:** once ε spent ≥ cap the service responds with HTTP 429 detailing the policy, remaining budget (always ≥0), and the next calendar reset.

## Repository Layout
- `src/dp_core/`: hashing, sketches, DP mechanisms, pipeline, windows, config.
- `src/service/`: FastAPI entrypoint, routes, schemas, auth utilities, OpenAPI tweaks.
- `eval/`: synthetic generators, adversarial workloads, evaluation harness, plots, notebook.
- `cli/dpdau.py`: Typer CLI for ingest/query/eval tasks.
- `tests/`: pytest suites for sketches, DP noise, pipeline, accountant, and service.
- `docker/`: containerization assets; respect `{{DATA_DIR}}` volume mounts.

## Setup & Commands
| Command | Purpose |
| --- | --- |
| `make setup` | Install pre-commit hooks, verify placeholder ledger. |
| `make fmt` | Run `black` + `ruff`. |
| `make lint` | Run `ruff check` and `mypy`. |
| `make test` | Execute pytest with coverage and placeholder check. |
| `make run` | Launch FastAPI via uvicorn (reload). |
| `make eval` | Execute synthetic workload in `eval/evaluate.py`. |
| `make plots` | Generate plots under `{{DATA_DIR}}/plots/{{EXPERIMENT_ID}}/`. |

## API Examples
- Ingest batch: `curl -X POST http://localhost:8000/event -H "Content-Type: application/json" -d '{"events":[{"user_id":"u1","op":"+","day":"2025-10-01"},{"user_id":"u1","op":"-","day":"2025-10-01"}]}'`
- Query DAU: `curl http://localhost:8000/dau/2025-10-01`
- Query MAU: `curl "http://localhost:8000/mau?end=2025-10-31&window={{MAU_WINDOW_DAYS}}"`
- Inspect budget ledger: `curl "http://localhost:8000/budget/mau?day=2025-10-31"`
- Metrics: scrape Prometheus counters at `/metrics`; latency histograms per route.

Every metric response now returns a `budget` object containing `epsilon_spent`, `epsilon_remaining`, `epsilon_cap`, and the best Rényi-derived `(ε,δ)` pair.

## CLI Helpers
- `dpdau generate-synthetic --days {{DAYS}} --users {{N_USERS}} --p-active {{P_ACTIVE}} --delete-rate {{DELETE_RATE}} --out {{EXAMPLE_DATASET_PATH}}` writes both JSONL and CSV variants to `{{DATA_DIR}}/streams/`, capturing deletes in the metadata.
- `dpdau ingest --from {{EXAMPLE_DATASET_PATH}} --format jsonl --host {{SERVICE_HOST}} --api-key {{SERVICE_API_KEY}}` batches events through the running API; omit `--host` to ingest via the in-process pipeline.
- `dpdau dau --day YYYY-MM-DD` and `dpdau mau --end YYYY-MM-DD --window {{MAU_WINDOW_DAYS}}` mirror the HTTP endpoints. When `--host` / `--api-key` are supplied, they print a short summary to stderr and stream the JSON response to stdout for piping.
- `dpdau reset-budget dau 2025-10` and `dpdau flush-deletes` wrap maintenance tasks (budget resets and erasure replay).
- `dpdau rotate-salt --effective 2025-11-01` generates a new `{{HASH_SALT_SECRET}}` and rotation cadence for secrets management.
- `python tools/export_budget_report.py --sample-days 3 --daily-users 100` snapshots `/budget/{metric}` responses to `{{DATA_DIR}}/reports/budget-snapshot.json`; CI runs this automatically after pytest.

## Budget Observability & Alerts
- Every `make test` invocation now emits `{{DATA_DIR}}/reports/budget-snapshot.json` capturing the latest DAU/MAU ε spend, Rényi curve, and advanced-composition bound `(advanced_epsilon, advanced_delta)`; upload alongside `coverage.xml` in CI for traceability.
- To baseline traffic, monitor `/metrics` counters (`app_requests_total`, `app_requests_5xx_total`, `app_request_latency_seconds_*`). Configure alerting to page on sustained `app_requests_total{handler="/event"}` growth without matching latency improvements, and fire a high-severity alert when you observe >10 `app_requests_5xx_total` increments within five minutes.
- Budget exhaustion returns HTTP 429 with a structured payload containing the current spend, cap, `policy.composition`, and next reset window; on-call runbooks should capture this payload plus the latest budget snapshot.
- For incident handoffs, include the budget snapshot plus `curl /budget/{metric}` outputs alongside Prometheus scrapes.

## Metrics
- The `/metrics` endpoint emits Prometheus text exposition with per-route counters and latency histograms:

  ```
  app_requests_total{handler="/event",method="POST",status="202"} 42
  app_requests_5xx_total{handler="/event",method="POST"} 0
  app_request_latency_seconds_bucket{handler="/dau",method="GET",le="0.50"} 18
  app_request_latency_seconds_sum{handler="/dau",method="GET"} 3.241
  ```
- Alerting thresholds should key off `app_requests_5xx_total` and the histogram P99 bucket for `/event` and `/dau`.
- Prometheus scrape example:

  ```yaml
  scrape_configs:
    - job_name: dp_dau_mau
      metrics_path: /metrics
      static_configs:
        - targets: ["127.0.0.1:8000"]
      relabel_configs:
        - source_labels: [__address__]
          target_label: instance
  ```

## Load Testing
- Install the optional dependency: `pip install .[load]` (or `pip install locust`).
- Run a headless stress test against a local service:  
  `SERVICE_API_KEY=dev-secret-key make load-test LOAD_USERS=2000 LOAD_SPAWN=500 LOAD_RUNTIME=5m LOAD_HOST=http://127.0.0.1:8000`
- The Locust harness (`load/locustfile.py`) generates batched `/event` traffic and probes `/dau`/`/mau`; adjust `LOAD_TEST_SEED` to reproduce runs.
- Inspect Locust CSV/HTML output (if enabled) alongside `/metrics` to verify the pipeline sustains 10–50k events/s.

## Evaluation Workflow
Run `python eval/simulate.py --users {{N_USERS}} --p-active {{P_ACTIVE}} --delete-rate {{DELETE_RATE}} --days 60 --out {{DATA_DIR}}/streams/sim.jsonl`. Reproduce accuracy curves via `python eval/evaluate.py --sketches set theta --epsilons 0.1 0.3 0.5`. `eval/plots.py` exports Matplotlib PNGs to `{{DATA_DIR}}/plots/{{EXPERIMENT_ID}}/`. Notebook `eval/notebooks/evaluation.ipynb` stitches figures into a reproducible story; update metadata after major changes.

## Changelog
- **Phase 2 (October 2025)**
  - Added end-to-end FastAPI tests covering ingest → releases → deletions → budget with API key enforcement.
  - Implemented an RDP-backed privacy accountant storing ε(α) curves, computing best (ε,δ), and enriching `/budget/{metric}` responses with composition notes and remaining monthly caps.
  - Secured `/event`, `/dau`, `/mau`, and `/budget` with optional `X-API-Key` auth surfaced in the OpenAPI document.
  - Replaced per-route timers with middleware-driven Prometheus metrics and text/plain exposition (`app_requests_total`, `app_requests_5xx_total`, latency histograms).
  - Refactored the Typer CLI: synthetic workload generation now emits JSONL+CSV under `{{DATA_DIR}}/streams`, ingestion accepts `--from/--format`, and remote queries stream JSON while printing human summaries.
  - Delivered operational tooling: `scripts/smoke.sh`, `tools/export_budget_report.py` (HTTP-based), and GitHub Actions coverage gating driven by {{COVERAGE_THRESHOLD}}.
  - Strengthened placeholder hygiene (`tools/check_placeholders.py` in CI) and ensured `make test`/CI archive `coverage.xml` plus the budget snapshot.

## Limitations
- PoC assumes single-process SQLite; scale-out requires queueing and shared stores.
- Theta and HLL++ implementations degrade gracefully when optional deps missing; rebuild strategy may be costly.
- Privacy accountant tracks naive ε and configurable RDP orders but lacks advanced composition/auto-tuning.
- High-delete adversaries may trigger full window rebuilds; optimization ideas listed in `HANDOFF.md`.
