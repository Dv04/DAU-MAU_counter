"""Ingestion and release pipeline orchestration."""

from __future__ import annotations

import datetime as dt
import json
import math
import os
import random
from collections.abc import Iterable
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, Literal

from . import config as config_module
from .dp_mechanisms import MechanismResult, gaussian_mechanism, laplace_mechanism
from .hashing import hash_user_id, hash_user_root
from .ledger import ActivityEntry, ErasureEntry, Ledger
from .privacy_accountant import BudgetCaps, PrivacyAccountant
from .sketches.base import SketchConfig, SketchFactory
from .sketches.kmv_impl import KMVSketch
from .sketches.set_impl import SetSketch
from .windows import WindowManager


class BudgetExceededError(Exception):
    """Raised when attempting to exceed the allocated privacy budget."""

    def __init__(self, metric: str, day: dt.date, cap: float, spent: float) -> None:
        self.metric = metric
        self.day = day
        self.cap = cap
        self.spent = spent
        self.period = day.strftime("%Y-%m")
        message = (
            f"{metric} budget exhausted for {day.isoformat()} (spent={spent:.4f}, cap={cap:.4f})"
        )
        super().__init__(message)


@dataclass(slots=True)
class EventRecord:
    user_id: str
    op: Literal["+", "-"]
    day: dt.date
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_json(self) -> str:
        return json.dumps(self.metadata or {})


def _seed_for(metric: str, day: dt.date, default_seed: int) -> int:
    digest = sha256(f"{metric}:{day.isoformat()}:{default_seed}".encode()).digest()
    value = int.from_bytes(digest[:8], "big", signed=False)
    return value & 0x7FFF_FFFF_FFFF_FFFF


class PipelineManager:
    def __init__(
        self,
        config: config_module.AppConfig | None = None,
        ledger: Ledger | None = None,
        accountant: PrivacyAccountant | None = None,
    ) -> None:
        self.config = config or config_module.AppConfig.from_env()
        ledgers_dir = self.config.storage.data_dir / "ledgers"
        ledgers_dir.mkdir(parents=True, exist_ok=True)
        ledger_path = ledgers_dir / "ledger.sqlite"
        self.ledger = ledger or Ledger(ledger_path)
        accountant_path = ledgers_dir / "dp_budget.sqlite"
        self.accountant = accountant or PrivacyAccountant(accountant_path)
        days_per_month = 31

        def _should_autoscale(env_var: str, default_value: float) -> bool:
            raw = os.environ.get(env_var)
            if raw is None:
                return True
            text = str(raw).strip()
            if config_module.PLACEHOLDER_PATTERN.fullmatch(text) is not None:
                return True
            try:
                value = float(text)
            except ValueError:
                return False
            return math.isclose(value, default_value, rel_tol=1e-9, abs_tol=1e-9)

        dau_cap = (
            max(self.config.dp.dau_budget_total, self.config.dp.epsilon_dau * days_per_month)
            if _should_autoscale("DAU_BUDGET_TOTAL", 3.0)
            else self.config.dp.dau_budget_total
        )
        mau_cap = (
            max(self.config.dp.mau_budget_total, self.config.dp.epsilon_mau * days_per_month)
            if _should_autoscale("MAU_BUDGET_TOTAL", 3.5)
            else self.config.dp.mau_budget_total
        )
        self.budgets = BudgetCaps(dau=dau_cap, mau=mau_cap)
        self.events_loader = self.ledger.fetch_day_events
        self.sketch_factory = self._build_sketch_factory()
        self.window_manager = WindowManager(
            sketch_factory=self.sketch_factory,
            hll_rebuild_buffer=self.config.sketch.hll_rebuild_days_buffer,
        )

    def _build_sketch_factory(self) -> SketchFactory:
        sketch_cfg = SketchConfig(
            k=self.config.sketch.k,
            use_bloom_for_diff=self.config.sketch.use_bloom_for_diff,
            bloom_fp_rate=self.config.sketch.bloom_fp_rate,
        )
        factory = SketchFactory(
            config=sketch_cfg, backends={}, default_impl=self.config.sketch.impl
        )
        factory.register(
            "set",
            lambda cfg: SetSketch(cfg),
            lambda payload, cfg: SetSketch.deserialize(payload, cfg),
        )
        factory.register(
            "kmv",
            lambda cfg: KMVSketch(cfg),
            lambda payload, cfg: KMVSketch.deserialize(payload, cfg),
        )
        try:
            from .sketches.theta_impl import ThetaSketch, ThetaSketchUnavailableError

            factory.register(
                "theta",
                lambda cfg: ThetaSketch(cfg),
                lambda payload, cfg: ThetaSketch.deserialize(payload, cfg),
            )
            if self.config.sketch.impl == "theta":  # fail fast if backend missing
                ThetaSketch(sketch_cfg).compact()
        except ThetaSketchUnavailableError:
            if self.config.sketch.impl == "theta":
                raise
        if self.config.sketch.impl not in factory.backends:
            raise RuntimeError(
                f"Requested sketch implementation '{self.config.sketch.impl}' is unavailable."
            )
        return factory

    def ingest_event(self, event: EventRecord) -> None:
        if event.op not in {"+", "-"}:
            raise ValueError("Event op must be '+' or '-'.")
        day_str = event.day.isoformat()
        user_key = hash_user_id(event.user_id, event.day, self.config)
        user_root = hash_user_root(event.user_id, self.config)

        activity_entry = ActivityEntry(
            day=day_str,
            user_key=user_key,
            user_root=user_root,
            op=event.op,
            metadata=event.as_json(),
        )
        self.ledger.record_activity(activity_entry)
        self.window_manager.mark_dirty(day_str)

        if event.op == "-":
            days = event.metadata.get("days")
            if not days:
                days = self.ledger.days_for_user(user_root)
            if day_str not in days:
                days.append(day_str)
            erasure_entry = ErasureEntry(
                erasure_id=None, user_root=user_root, days=days, pending=True
            )
            self.ledger.record_erasure(erasure_entry)
            for affected_day in set(days):
                self.window_manager.mark_dirty(affected_day)

    def ingest_batch(self, events: Iterable[EventRecord]) -> None:
        for event in events:
            self.ingest_event(event)

    def replay_deletions(self) -> None:
        pending = self.ledger.pending_erasures()
        for erasure in pending:
            for day in erasure.days:
                self.window_manager.mark_dirty(day)
            if erasure.erasure_id is not None:
                self.ledger.mark_erasure_processed(erasure.erasure_id)

    def _release(
        self,
        metric: Literal["dau", "mau"],
        day: dt.date,
        base_value: float,
        sensitivity: float,
    ) -> MechanismResult:
        epsilon = self.config.dp.epsilon_dau if metric == "dau" else self.config.dp.epsilon_mau
        delta = self.config.dp.delta if metric == "mau" else 0.0
        cap = self.budgets.dau if metric == "dau" else self.budgets.mau
        if not self.accountant.can_release(metric, epsilon, day, cap):
            spent = self.accountant.spent_budget(metric, day)
            raise BudgetExceededError(metric, day, cap, spent)
        seed = _seed_for(metric, day, self.config.dp.default_seed)
        rng = random.Random(seed)
        if delta > 0:
            result = gaussian_mechanism(
                value=base_value,
                sensitivity=sensitivity,
                epsilon=epsilon,
                delta=delta,
                rng=rng,
                seed=seed,
            )
        else:
            result = laplace_mechanism(
                value=base_value,
                sensitivity=sensitivity,
                epsilon=epsilon,
                rng=rng,
                seed=seed,
            )
        self.accountant.record_release(
            metric=metric,
            day=day,
            epsilon=epsilon,
            delta=delta,
            mechanism=result.mechanism,
            seed=seed,
        )
        self._log_rdp_release(metric, day, result)
        return result

    def get_daily_release(self, day: dt.date) -> dict[str, Any]:
        self.replay_deletions()
        day_str = day.isoformat()
        estimate, _sketch, exact_count = self.window_manager.get_dau(day_str, self.events_loader)
        base_value = float(exact_count)
        sensitivity = float(min(self.config.dp.w_bound, 1))
        dp_result = self._release("dau", day, base_value, sensitivity)
        budget = self.accountant.budget_snapshot(
            "dau",
            day,
            self.budgets.dau,
            0.0,
            self.config.dp.rdp_orders,
            self.config.dp.advanced_delta,
        )
        return {
            "day": day_str,
            "estimate": dp_result.noisy_value,
            "lower_95": dp_result.confidence_interval[0],
            "upper_95": dp_result.confidence_interval[1],
            "epsilon_used": dp_result.epsilon,
            "delta": dp_result.delta,
            "mechanism": dp_result.mechanism,
            "sketch_impl": self.config.sketch.impl,
            "budget_remaining": budget.epsilon_remaining,
            "budget": budget.as_dict(),
            "exact_value": base_value,
        }

    def get_mau_release(self, end_day: dt.date, window_days: int | None = None) -> dict[str, Any]:
        self.replay_deletions()
        window = window_days or self.config.sketch.mau_window_days
        end_day_str = end_day.isoformat()
        value, _union = self.window_manager.get_mau(end_day_str, window, self.events_loader)
        base_value = float(value)
        sensitivity = float(self.config.dp.w_bound)
        dp_result = self._release("mau", end_day, base_value, sensitivity)
        budget = self.accountant.budget_snapshot(
            "mau",
            end_day,
            self.budgets.mau,
            self.config.dp.delta,
            self.config.dp.rdp_orders,
            self.config.dp.advanced_delta,
        )
        return {
            "day": end_day_str,
            "window_days": window,
            "estimate": dp_result.noisy_value,
            "lower_95": dp_result.confidence_interval[0],
            "upper_95": dp_result.confidence_interval[1],
            "epsilon_used": dp_result.epsilon,
            "delta": dp_result.delta,
            "mechanism": dp_result.mechanism,
            "sketch_impl": self.config.sketch.impl,
            "budget_remaining": budget.epsilon_remaining,
            "budget": budget.as_dict(),
            "exact_value": base_value,
        }

    def reset_budget(self, metric: str, month: str) -> None:
        self.accountant.reset_month(metric, month)

    def get_budget_summary(self, metric: str, day: dt.date) -> dict[str, Any]:
        metric = metric.lower()
        if metric not in {"dau", "mau"}:
            raise ValueError("metric must be 'dau' or 'mau'")
        cap = self.budgets.dau if metric == "dau" else self.budgets.mau
        delta = 0.0 if metric == "dau" else self.config.dp.delta
        snapshot = self.accountant.budget_snapshot(
            metric,
            day,
            cap,
            delta,
            self.config.dp.rdp_orders,
            self.config.dp.advanced_delta,
        )
        return snapshot.as_dict()

    def _log_rdp_release(self, metric: str, day: dt.date, result: MechanismResult) -> None:
        orders = getattr(self.config.dp, "rdp_orders", ())
        if not orders:
            return
        rdp_points: dict[float, float] = {}
        if result.mechanism == "gaussian":
            if result.delta <= 0:
                return
            sigma = (
                math.sqrt(2 * math.log(1.25 / result.delta))
                * result.sensitivity
                / max(result.epsilon, 1e-12)
            )
            if sigma <= 0:
                return
            variance = sigma * sigma
            for order in orders:
                if order <= 1:
                    continue
                rdp = (order * (result.sensitivity**2)) / (2 * variance)
                rdp_points[float(order)] = rdp
        else:
            for order in orders:
                if order <= 1:
                    continue
                rdp = (order / (order - 1.0)) * result.epsilon
                rdp_points[float(order)] = rdp
        if rdp_points:
            self.accountant.log_rdp_points(metric, day, rdp_points)
